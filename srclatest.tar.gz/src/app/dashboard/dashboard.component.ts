import { Component, OnInit } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { AuthService } from '../auth.service';
import { WelcomeComponent } from '../welcome/welcome.component';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {


  public userObject :any;
  public tokens:any;
  public refreshTokens:any;
  constructor(protected readonly keycloak:KeycloakService) { }

  async ngOnInit(): Promise<void> {
    this.userObject=await this.keycloak.loadUserProfile();
    this.tokens=await this.keycloak.getToken();
    this.refreshTokens=this.keycloak.getKeycloakInstance().refreshToken;
    
  }

  logout()
  {
    console.log("logout");
 
    this.keycloak.logout('http://localhost:4200/');
    WelcomeComponent.staticVariable1=false;
  }
  async update()
  {
    await this.keycloak.updateToken(-1).then(async()=>{
      this.tokens=await this.keycloak.getToken();
    })
    this.refreshTokens=this.keycloak.getKeycloakInstance().refreshToken;
  }
}
